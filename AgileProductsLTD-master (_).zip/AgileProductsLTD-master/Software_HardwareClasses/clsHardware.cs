﻿namespace Software_HardwareClasses
{
    public class clsHardware
    {
    }
}