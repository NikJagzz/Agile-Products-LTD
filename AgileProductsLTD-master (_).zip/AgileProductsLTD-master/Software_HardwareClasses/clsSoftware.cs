﻿namespace Software_HardwareClasses
{
    public class clsSoftware
    {
    }
}